import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:csv/csv.dart';

import '../models/reading_model.dart';
import '../config/app_colors.dart';

class ReadingsPage extends StatefulWidget {
  const ReadingsPage({super.key});

  @override
  State<ReadingsPage> createState() => _ReadingsPageState();
}

class _ReadingsPageState extends State<ReadingsPage> {
  List<ReadingModel> readings = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final box = await Hive.openBox<ReadingModel>('readings');
    setState(() {
      readings = box.values.toList();
    });
  }

  Future<void> _exportToCsv() async {
    if (readings.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('هیچ داده‌ای برای صادر کردن وجود ندارد.')),
      );
      return;
    }

    List<List<dynamic>> rows = [];

    // سرفصل ستون‌ها
    rows.add([
      'اشتراک',
      'موبایل',
      'توضیح',
      'عرض جغرافیایی',
      'طول جغرافیایی',
      'تاریخ ثبت',
    ]);

    // اضافه کردن داده‌ها
    for (var r in readings) {
      rows.add([
        r.subscriptionNumber,
        r.phone,
        r.description,
        r.lat.toStringAsFixed(6),
        r.lng.toStringAsFixed(6),
        r.createdAt.toString(),
      ]);
    }

    String csv = const ListToCsvConverter().convert(rows);

    // مسیر ذخیره فایل
    final directory = await getTemporaryDirectory();
    final path = '${directory.path}/readings.csv';

    final file = File(path);
    await file.writeAsString(csv);

    // اشتراک‌گذاری فایل
    await Share.shareFiles([path], text: 'فایل اطلاعات ثبت شده');
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('اطلاعات ثبت شده'),
          backgroundColor: AppColors.primary,
          actions: [
            IconButton(
              icon: const Icon(Icons.download),
              tooltip: 'دریافت فایل CSV',
              onPressed: _exportToCsv,
            ),
          ],
        ),
        body: readings.isEmpty
            ? const Center(child: Text('هیچ اطلاعاتی ثبت نشده است.'))
            : ListView.builder(
          itemCount: readings.length,
          itemBuilder: (context, index) {
            final r = readings[index];
            return Card(
              margin: const EdgeInsets.all(8),
              child: ListTile(
                title: Text('اشتراک: ${r.subscriptionNumber}'),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('موبایل: ${r.phone}'),
                    Text('توضیح: ${r.description}'),
                    Text(
                        'مکان: (${r.lat.toStringAsFixed(4)}, ${r.lng.toStringAsFixed(4)})'),
                    Text('تاریخ: ${r.createdAt.toString().substring(0, 19)}'),
                  ],
                ),
                isThreeLine: true,
              ),
            );
          },
        ),
      ),
    );
  }
}
