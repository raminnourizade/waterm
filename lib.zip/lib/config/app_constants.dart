class AppConstants {
  static const double borderRadius = 20;
  static const double padding = 24;
  static const double cardElevation = 8;
// هر کانستنت دیگری که مکرراً استفاده می‌کنی
}
